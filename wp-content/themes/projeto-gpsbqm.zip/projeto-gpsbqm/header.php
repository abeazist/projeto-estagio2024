<!DOCTYPE html>
<html lang="PT-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BEAGrupo de Pesquisa UTFPR-CM</title>
    <?php wp_head(); ?>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="stylesheet" type="text/css" href="wp-content/themes/teste/style.css">
    <link rel="stylesheet" href="template.css">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Atkinson+Hyperlegible:ital,wght@0,400;0,700;1,400;1,700&display=swap" rel="stylesheet">
</head>
<body <?php body_class(); ?>>
    <header>
            <span class="logotipo">
            <svg xmlns="http://www.w3.org/2000/svg" height="48px" viewBox="0 -960 960 960" width="48px" fill="#FFFFFF"><path d="M172-120q-41.78 0-59.39-39T124-230l248-280v-270h-52q-12.75 0-21.37-8.68-8.63-8.67-8.63-21.5 0-12.82 8.63-21.32 8.62-8.5 21.37-8.5h320q12.75 0 21.38 8.68 8.62 8.67 8.62 21.5 0 12.82-8.62 21.32-8.63 8.5-21.38 8.5h-52v270l248 280q29 32 11.39 71T788-120H172Zm-12-60h640L528-488v-292h-96v292L160-180Zm318-300Z"/></svg>
                GPSBQM
            </span>
            <nav class="menu">
                <ul>
                    <li><a href="">Início</a></li>
                    <li><a href="">Projetos</a></li>
                    <li><a href="">Equipe</a></li>
                    <li><a href="">Fotos</a></li>
                    <li><a href="">Conta</a></li>
                    
                </ul>
                <p>beatriz</p>
        
            </nav>
            <a href=""><button>Conta</button></a>
            
    </header>
    